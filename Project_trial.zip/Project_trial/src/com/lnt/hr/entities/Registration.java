package com.lnt.hr.entities;


import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.transaction.TransactionScoped;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name="STUDENTREGISTRATION")
public class Registration 
{
	
	  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="IDSTUDENT_SEQ")
	@SequenceGenerator(name = "IDSTUDENT_SEQ", sequenceName = "seq_student", allocationSize = 1)
	@Id
	@Column(name = "STUDENTID") 
	private long studentId; 
	@Column(name="STATEOFDOMICILE")
	private String stateOfDomicile;
	@Column(name="DISTRICT")
	private String district;
	@Column(name="NAME")
	private String name;
	@Column(name="DATEOFBIRTH")
	private String dateOfBirth;
	@Column(name="GENDER")
	private String gender;
	@Column(name="MOBILENO")
	private long mobileNo;
	@Column(name="EMAIL")
	private String email;
	@Column(name="INSTITUTECODE")
	private long instituteCode;
	@Column(name="AADHAARNUMBER")
	private long aadhaarNumber;
	@Column(name="BANKIFSC")
	private String bankIFSC;
	@Column(name="BANKACCOUNTNUMBER")
	private long bankAccountNumber; 
	@Column(name="BANKNAME")
	private String bankName;
	@Column(name="PASSWORD")
	private String password;
	@Transient
	private String repassword;
	
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Registration(long studentId, String stateOfDomicile, String district, String name, String dateOfBirth,
			String gender, long mobileNo, String email, long instituteCode, long aadhaarNumber, String bankIFSC,
			long bankAccountNumber, String bankName, String password, String repassword) {
		super();
		this.studentId = studentId;
		this.stateOfDomicile = stateOfDomicile;
		this.district = district;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.email = email;
		this.instituteCode = instituteCode;
		this.aadhaarNumber = aadhaarNumber;
		this.bankIFSC = bankIFSC;
		this.bankAccountNumber = bankAccountNumber;
		this.bankName = bankName;
		this.password = password;
		this.repassword = repassword;
	}

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public String getStateOfDomicile() {
		return stateOfDomicile;
	}

	public void setStateOfDomicile(String stateOfDomicile) {
		this.stateOfDomicile = stateOfDomicile;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getInstituteCode() {
		return instituteCode;
	}

	public void setInstituteCode(long instituteCode) {
		this.instituteCode = instituteCode;
	}

	public long getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(long aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getBankIFSC() {
		return bankIFSC;
	}

	public void setBankIFSC(String bankIFSC) {
		this.bankIFSC = bankIFSC;
	}

	public long getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(long bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepassword() {
		return repassword;
	}

	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}

	@Override
	public String toString() {
		return "Registration [studentId=" + studentId + ", stateOfDomicile=" + stateOfDomicile + ", district="
				+ district + ", name=" + name + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", mobileNo="
				+ mobileNo + ", email=" + email + ", instituteCode=" + instituteCode + ", aadhaarNumber="
				+ aadhaarNumber + ", bankIFSC=" + bankIFSC + ", bankAccountNumber=" + bankAccountNumber + ", bankName="
				+ bankName + ", password=" + password + ", repassword=" + repassword + "]";
	}

		
	
	
		

}
