package com.lnt.hr.eligibility;

import com.lnt.hr.entities.Scholarship;

public interface CheckEligibility 
{
	public String checkEligibility(Scholarship scholarship);

}
