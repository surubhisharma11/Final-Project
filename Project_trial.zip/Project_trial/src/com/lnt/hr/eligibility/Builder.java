package com.lnt.hr.eligibility;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

@Service("Builder")
public class Builder 
{
	private CheckPragatiEligibility ce1;
	private CheckEligibility ce2;
	private CheckEligibility ce3;
	
	
	@Autowired(required=true)
	private WebApplicationContext ctx;

	@PostConstruct
	public void initializeBuilder()
	{	
		//System.out.println("Builder object created.");
		ce1 = (CheckPragatiEligibility) ctx.getBean("Pragati");
		ce2 = (CheckEligibility) ctx.getBean("MeritBased");
		ce3= (CheckEligibility) ctx.getBean("MinorityBased");
	}
	
	
	public CheckEligibility getEligibilityStrategy(String scheme)
	{
		switch(scheme)
		{
		case "MeritBased":
			return ce2;
		case "MinorityBased":
			return ce3;
		default:
			return null;
		}
		
	}
	
	
	public CheckPragatiEligibility getPragatiEligibilityStrategy(String scheme)
	{
		switch(scheme)
		{
		case "Pragati":
			return ce1;
		default:
			return null;
		}
		
	}
}
