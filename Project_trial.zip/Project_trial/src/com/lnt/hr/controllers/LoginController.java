package com.lnt.hr.controllers;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.entities.InsLogin;
import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;
import com.lnt.hr.services.InsLoginService;
import com.lnt.hr.services.LoginService;
import com.lnt.hr.services.LoginServiceImpl;

@Controller("LoginController")
public class LoginController 
{
	@Resource
	private LoginService loginServices ;
	
	@Resource
	private InsLoginService insloginServices;



	//************************institute login authentication*******************************
	
	@RequestMapping("/getInstituteHomePage")
	public ModelAndView getInstituteHomePage(HttpServletRequest request)
	{
		int loginCheck=0;
		int loginID=Integer.parseInt(request.getParameter("instituteCode"));
		//System.out.println(loginID);
		String password =request.getParameter("psw");
		//System.out.println(password);

		ModelAndView mv=new ModelAndView("InstituteHome");

		try 
		{
			loginCheck = insloginServices.insloginCheck(new InsLogin(loginID, password));
			mv.addObject("loginID", loginID);
		} 
		catch (LoginException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		if(loginCheck !=-1)
		{
			mv.addObject("loginID", loginID);
			return mv;
		}
		else
		{
			mv.addObject("message", "Invalid LoginID/password.");
			mv.setViewName("errorPage");
		}

		return mv;

	}
	//************************student login authentication*******************************
	@RequestMapping("/submitForm1")
	
	public ModelAndView NewStudentJoined(HttpServletRequest request) throws LoginException 
	{
		int loginCheck=0;
		int loginID=Integer.parseInt(request.getParameter("stuLoginID"));
		//System.out.println(loginID);
		String password =request.getParameter("password");
		//System.out.println(password);

		ModelAndView mv=new ModelAndView("studentRegPage");
		try 
		{
			loginCheck = loginServices.loginCheck(new Login(loginID, password));
		} 
		catch (LoginException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if(loginCheck !=-1)
		{
			mv.addObject("loginID", loginID);
			return mv;
		}
		else
		{
			mv.addObject("message", "Invalid LoginID/password.");
			mv.setViewName("errorPage");
		}

		return mv;
	}

	//************************ministry login authentication*******************************
	@RequestMapping("/getMinistryhome")
	public ModelAndView getMinistryHomePage(HttpServletRequest request)
	{
		int loginCheck=0;
		int loginID=Integer.parseInt(request.getParameter("stuLoginID"));
		//System.out.println(loginID);
		String password =request.getParameter("password");
		//System.out.println(password);
		//System.out.println("in minsitry auth");
		ModelAndView mv=new ModelAndView("ministryHome");
		
		ModelAndView mv1 =new ModelAndView("ministryHome");
		int flag = 0;

		try 
		{
			loginCheck = loginServices.loginCheck(new Login(loginID, password));
		} 
		catch (LoginException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("loginCheck"+loginCheck);

		if(loginCheck !=-1)
		{
			//ModelAndView mv1 =new ModelAndView("ministryHome");
			flag=1;
			//System.out.println("in if loop");
			//mv.setViewName("ministryHome");
			mv1.addObject("loginID", loginID);
			//System.out.println("befoer");
			return mv1;
		}
		else
		{	

			//System.out.println("in else loop");
			mv.addObject("message", "Invalid LoginID/password.");
			mv.setViewName("errorPage");
		}
		//System.out.println(flag);
		if(flag==1)
		{
			return mv1;
		}
		else
		{

			return mv;

		}

	}

	@RequestMapping("/submitForm2")
	public String loginSuccess()
	{
		return "loginSuccess";
	}

}
