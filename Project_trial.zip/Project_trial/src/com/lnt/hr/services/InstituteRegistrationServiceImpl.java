package com.lnt.hr.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.hr.daos.InstituteRegistrationDao;
import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.RegistrationException;


@Service("InstituteRegistrationServiceImpl")
public class InstituteRegistrationServiceImpl implements InstituteRegistrationService 
{
	@Autowired
	InstituteRegistrationDao dao;

	@Override
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws RegistrationException
	{
		return dao.insertNewInstitute(instituteRegistration);
	}

	@Override
	public List<InstituteRegistration> getInsList() throws RegistrationException
	{
		return dao.getInsList();
	}

	@Override
	public InstituteRegistration getInsDetails(long instituteCode) throws RegistrationException 
	{
		return dao.getInsDetails(instituteCode);
	}
	
	

}
