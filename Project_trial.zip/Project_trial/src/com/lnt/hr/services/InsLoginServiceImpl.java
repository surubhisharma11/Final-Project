package com.lnt.hr.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.hr.daos.InsLoginDao;

import com.lnt.hr.entities.InsLogin;
import com.lnt.hr.exception.LoginException;

@Service("InsLoginServiceImpl")
public class InsLoginServiceImpl implements InsLoginService
{
	@Autowired
	InsLoginDao insloginDao;

	@Override
	public InsLogin insertNewInstitution(InsLogin inslogin) throws LoginException {
		return insloginDao.insertNewInstitution(inslogin);
	}

	@Override
	public int insloginCheck(InsLogin inslogin) throws LoginException {
		return insloginDao.insloginCheck(inslogin);
	}

}
