package com.lnt.hr.daos;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.exception.RegistrationException;

public interface RegistrationDao 
{
	public Registration insertNewStudent(Registration registration) throws RegistrationException;

}
