package com.lnt.hr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.InsLogin;

import com.lnt.hr.exception.LoginException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class InsLoginDaoImpl implements InsLoginDao
{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public InsLogin insertNewInstitution(InsLogin inslogin) throws LoginException {
		try
		{
			entityManager.persist(inslogin);
			return inslogin;
		}
		catch(Exception e)
		{
			throw new LoginException("OOP's!!! Something went wrong while inserting a new institution", e);
		}
	}

	@Override
	public int insloginCheck(InsLogin inslogin) throws LoginException {
		Query query = entityManager.createQuery("select loginId from InsLogin where loginId=:loginId and password= :password");
		query.setParameter("loginId", inslogin.getLoginId());
		query.setParameter("password", inslogin.getPassword());
		List<Integer> userDetailsList = query.getResultList();
		
		if(userDetailsList.size()>0)
		{
			return userDetailsList.get(0);
		}
		return -1;
	}

}
